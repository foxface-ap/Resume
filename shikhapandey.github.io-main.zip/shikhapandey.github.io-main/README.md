# Attractive Advance Portfolio Website
## _Chatting Bot Like Design (Whatsapp like interface)_
-[Visit Link](https://shikha-code36.github.io/shikhapandey.github.io/)

## Technologies Used

- HTML
- Javascript
- CSS

## Features

- Whatsapp like interface
- Pleasant sounds
- Lightweighted
- Social media links
- Download resume.
- Map support for address

<br><br>

**Free Software, Hell Yeah!**
